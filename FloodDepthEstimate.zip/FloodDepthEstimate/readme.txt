The name of the program: 
	FloodDepthEstimate

The title of the manuscript:
	End-to-end multi-reference detection and flood depth estimation model considering multi-dimensional perspectives

The author details:
	Heng Tang, School of Earth Sciences and Engineering, Hohai University, Nanjing, China, tangh115@163.com
	Xiaoping Rui [The corresponding author], School of Earth Sciences and Engineering, Hohai University, Nanjing, China, ruixpsz@163.com
	Ninglei OuYangc School of Earth Sciences and Engineering, Hohai University, Nanjing, China, ouyangnl@126.com
	Yiheng Xie, School of Earth Sciences and Engineering, Hohai University, Nanjing, China, xieyiheng0303@163.com
	Hongyue Zhang, School of Earth Sciences and Engineering, Hohai University, Nanjing, China, 221309020039@hhu.edu.cn
	Xiaodie Liu, School of Earth Sciences and Engineering, Hohai University, Nanjing, China, liuxiaodie0217@163.com
	Jiasheng Zhu, School of Earth Sciences and Engineering, Hohai University, Nanjing, China, 18775582113@163.com
	Jiayi Zhang, School of Earth Sciences and Engineering, Hohai University, Nanjing, China, zhangjiayiyu@163.com
	Pengyi Zhou School of Earth Sciences and Engineering, Hohai University, Nanjing, China, 241309020030@hhu.edu.cn

